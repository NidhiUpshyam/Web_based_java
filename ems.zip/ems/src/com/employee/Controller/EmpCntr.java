package com.employee.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.employee.dao.EmpDao;
import com.employee.dto.Employee;
import com.employee.service.EmpService;
import com.employee.valid.LoginValidator;
import com.employee.valid.RegValidator;

@Controller
public class EmpCntr {
	@Autowired
	private EmpService empserv;
	@Autowired
	private EmpDao e;
	@Autowired
	private  MailSender mailSender;
	@Autowired
	private LoginValidator uv;
	@Autowired
	private RegValidator rv;


	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("employee", new Employee());
		return "reg_form";
	}
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(Employee emp,BindingResult result, ModelMap map) {
		rv.validate(emp, result);
		if(result.hasErrors()) {
			return "reg_form";
		}
		empserv.insertEmployee(emp);
		return "index";
	}
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("employee", new Employee());
		return "login_form";
	}
	
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(Employee employee,BindingResult result, ModelMap map, HttpSession session) {
		uv.validate(employee, result);
		if(result.hasErrors()) {
			return "login_form";
		}
		boolean b = empserv.checkEmployee(employee);
		System.out.println(b);
		if(b) {
			session.setAttribute("employee", employee);
			return "home";
		}else {
			map.put("employee", new Employee());
			
			return "login_form";
		}
	}
	
	@RequestMapping(value = "/Employee_list.htm",method = RequestMethod.GET)
	public String employeeList(ModelMap map,HttpSession session)  {
		

		List<Employee> li = empserv.selectAllEmployee();
		/*
		 * for(Employee e:li) { System.out.println(e.getItemName());
		 * System.out.println(e.getPrice());
		 * 
		 * }
		 */
		map.put("employeeList", li);
		return "employee_list";
	}
	
	@RequestMapping(value = "/employee_edit.htm",method = RequestMethod.GET)
	public String userEdit(@RequestParam ("empId")int empId,ModelMap map,HttpSession session) {
		
		Employee e = empserv.findEmployee(empId); 
		System.out.println(empId);

		
		
		map.put("employee", e);
		return "edit";
	
	}

	@RequestMapping(value = "/employee_delete.htm",method = RequestMethod.GET)
	public String userDelete(@RequestParam int empId,ModelMap map,HttpSession session) {
		
		empserv.removeEmployee(empId); 
		System.out.println(empId);

		
		List<Employee> li = empserv.selectAllEmployee();
		map.put("employeeList", li);
		return "employee_list";
	
	}
	@RequestMapping(value = "/logout.htm",method = RequestMethod.GET)
	public String logout(ModelMap map, HttpSession session) {
		session.removeAttribute("employee");
		session.invalidate();
		return "index";
	}
	
	
	
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String empName,ModelMap map) {		
		String pass = empserv.forgotPassword(empName);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("nidhiupashyam@gmail.com");  
	        message.setTo(empName);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info";
	}
	@RequestMapping(value = "/edit.htm",method = RequestMethod.POST)
	public String userUpdate(Employee emp,ModelMap map,HttpSession session) {
		e.updateEmployeeDetails(emp);
		
		
		return "redirect:Employee_list.htm";
	
	}
	
	
	@RequestMapping(value = "/myprofile.htm",method = RequestMethod.GET)
	public String userDisplay(@RequestParam ("empId")int empId,ModelMap map,HttpSession session) {
		
		Employee e = empserv.findEmployee(empId); 
		System.out.println(empId);

		
		
		map.put("employee", e);
		return "myprofile";
	
	}
	
}
