package com.employee.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.employee.dto.Admin;


@Controller
public class AdmCntr {

	
	@RequestMapping(value = "/prep_log1_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "login1_form";
	}
	
	@RequestMapping(value = "/login1.htm",method = RequestMethod.POST)
	public String login(Admin admin,ModelMap map) {
		
	
		
		if(admin.getAdminName().equals("admin") && admin.getAdminPass().equals("pass")) {
			return "home1";
		}else {
			map.put("admin", new Admin());
			return "login1_form";
		}
	}
	
	

}
