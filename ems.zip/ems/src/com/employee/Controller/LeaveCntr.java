package com.employee.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.employee.dto.Employee;
import com.employee.dto.Leaves;
import com.employee.service.LeaveService;
import com.employee.valid.LeaveValidator;
@Controller
public class LeaveCntr {
	@Autowired
	private LeaveService leaveserv;
	
	@Autowired
	private LeaveValidator lv;

	@RequestMapping(value = "/prep_leave_form.htm",method = RequestMethod.GET)
	public String prepLeaveForm(ModelMap map) {
		map.put("leave", new Leaves());
		return "applyleave";
	}
	
	
	@RequestMapping(value = "/applyleave.htm",method = RequestMethod.POST)
	public String applyleave(@ModelAttribute("leave") Leaves leave,BindingResult result, ModelMap map) {
		leave.setLeaveStatus("Pending");
		lv.validate(leave, result);
		if(result.hasErrors()) {
			
			return "applyleave";
		}
		leaveserv.insertLeave(leave);
		map.put("leave", new Leaves());
		map.put("msg", "Leave applied successfully!!");
		return "applyleave";
	}
	
	@RequestMapping(value = "/Leave_list.htm",method = RequestMethod.GET)
	public String leaveList( @RequestParam ("empId")int empId, ModelMap map,HttpSession session)  {
		

		List<Leaves> li = leaveserv.findLeavebyEmpId(empId);
		/*
		 * for(Employee e:li) { System.out.println(e.getItemName());
		 * System.out.println(e.getPrice());
		 * 
		 * }
		 */
		map.put("leaveList", li);
		return "leave_list";
	}
	@RequestMapping(value = "/Employee_leave_list.htm",method = RequestMethod.GET)
	public String employeeLeaveList(ModelMap map,HttpSession session)  {
		

		List<Leaves> li = leaveserv.selectAllLeaves();
		/*
		 * for(Employee e:li) { System.out.println(e.getItemName());
		 * System.out.println(e.getPrice());
		 * 
		 * }
		 */
		map.put("leaveList", li);
		return "adminleave";
	}
	@RequestMapping(value = "/leave_edit.htm",method = RequestMethod.GET)
	public String leaveEdit(@RequestParam ("leaveId")int leaveId,ModelMap map,HttpSession session) {
		
		Leaves e = leaveserv.findLeave(leaveId); 
		System.out.println(leaveId);

		
		
		map.put("Leaves", e);
		return "leaveedit";
	
	}
	@RequestMapping(value = "/update_leave.htm",method = RequestMethod.POST)
	public String updateLeave(Leaves l,ModelMap map,HttpSession session) {
		leaveserv.updateLeave(l);
		
		
		return "redirect:Employee_leave_list.htm";
	
	}
}
