package com.employee.service;

import java.util.List;

import com.employee.dto.Leaves;

public interface LeaveService {

	

	void insertLeave(Leaves leave);

	List<Leaves> findLeavebyEmpId(int empId);

	List<Leaves> selectAllLeaves();

	Leaves findLeave(int leaveId);

	void updateLeave(Leaves l);
	
}
