package com.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dao.LeaveDao;
import com.employee.dto.Leaves;
@Service
public class LeaveServiceImple implements LeaveService {
@Autowired
	private LeaveDao leavedao;
	@Override
	public void insertLeave(Leaves leave) {
		
		// TODO Auto-generated method stub
		leavedao.insertLeave(leave);
		
	}
	@Override
	public List<Leaves> findLeavebyEmpId(int empId) {
		// TODO Auto-generated method stub
		return leavedao.findLeavebyEmpId( empId);
	}
	@Override
	public List<Leaves> selectAllLeaves() {
		// TODO Auto-generated method stub
		return leavedao.selectAllLeaves();

	}
	@Override
	public Leaves findLeave(int leaveId) {
		// TODO Auto-generated method stub
		return leavedao.findByLeaveId(leaveId) ;
	}
	@Override
	public void updateLeave(Leaves l) {
		// TODO Auto-generated method stub
		leavedao.updateLeave(l);
	}

}
