package com.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.dao.EmpDao;
import com.employee.dto.Employee;
@Service
public class EmpServiceImple implements EmpService{
	@Autowired
	private EmpDao empdao;
	
	

	@Override
	public void insertEmployee(Employee emp) {
		// TODO Auto-generated method stub
		empdao.insertEmployee(emp);
		
	}

	@Override
	public boolean checkEmployee(Employee emp) {
		// TODO Auto-generated method stub
		
		return empdao.checkEmployee(emp);
	}

	@Override
	public void removeEmployee(int empId) {
		// TODO Auto-generated method stub
		empdao.removeEmployee(empId);
	}

	@Override
	public List<Employee> selectAllEmployee() {
		// TODO Auto-generated method stub
		return empdao.selectAllEmployee();
	}

	@Override
	public Employee findEmployee(int empId) {
		// TODO Auto-generated method stub
	
		return empdao.findByEmployeeId(empId) ;
	}

	@Override
	public String forgotPassword(String empName) {
		// TODO Auto-generated method stub
		return empdao.forgotPassword(empName);
		
	}


	

}
