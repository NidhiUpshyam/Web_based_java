package com.employee.service;

import java.util.List;

import com.employee.dto.Employee;

public interface EmpService {
	void insertEmployee(Employee emp);
	boolean checkEmployee(Employee emp);
	void removeEmployee(int empId);
	List<Employee> selectAllEmployee();
	Employee findEmployee(int empId);
	String forgotPassword(String empName);
}
