package com.employee.dao;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.employee.dto.Employee;
@Repository

public class EmpDaoImple implements EmpDao{
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertEmployee(Employee emp) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {
       
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(emp);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public boolean checkEmployee(Employee emp) {
		boolean a= hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				// TODO Auto-generated method stub
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee where empName = ? and empPass = ?");
				q.setString(0, emp.getEmpName());
				q.setString(1, emp.getEmpPass());
				List<Employee> li = q.list();
				boolean flag = !li.isEmpty();
				if(flag)
					emp.setEmpId(li.get(0).getEmpId()); 
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
		});
		return a;
	}

	@Override
	public List<Employee> selectAllEmployee() {
		// TODO Auto-generated method stub
		
		return hibernateTemplate.execute(new HibernateCallback<List<Employee>>() {

			@Override
			public List<Employee> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee");
				List<Employee> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});

	}
	@Override
	public String forgotPassword(String empName) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Employee where empMail = ?");
				q.setString(0, empName);
				List<Employee> li = q.list();
				String pass = null;
				if(!li.isEmpty())
					pass = li.get(0).getEmpPass();
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}


	@Override
	public void removeEmployee(int empId) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Employee user = new Employee(empId);
				System.out.println(user);
				session.delete(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

		
	}

	@Override
	public Employee findByEmployeeId(int empId) {
		// TODO Auto-generated method stub
		return hibernateTemplate.execute(new HibernateCallback<Employee>() {

			@Override
			public Employee doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Employee e=(Employee) session.get(Employee.class,empId);
				tr.commit();
				session.flush();
				session.close();
				return e;
			}
			
		});
		
	}
	@Override
	public Employee updateEmployeeDetails(Employee list) {
	return	hibernateTemplate.execute(new HibernateCallback<Employee>() {
			@Override
			public Employee doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Employee ex = (Employee)session.get(Employee.class,list.getEmpId());
				ex.setEmpName(list.getEmpName());
				ex.setEmpCity(list.getEmpCity());	
				ex.setEmpDOB(list.getEmpDOB());
				ex.setEmpDOJ(list.getEmpDOJ());
				ex.setEmpMail(list.getEmpMail());
				ex.setEmpMobNo(list.getEmpMobNo());
				ex.setEmpJob(list.getEmpJob());
				session.update(ex);			
				tr.commit();
				session.flush();
				session.close();
				return ex;
			}			
		});

	}

	

}
