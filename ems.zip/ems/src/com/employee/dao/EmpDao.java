package com.employee.dao;

import java.util.List;

import com.employee.dto.Employee;


public interface EmpDao {
	void insertEmployee(Employee emp);
	boolean checkEmployee(Employee emp);
	List<Employee> selectAllEmployee();
	void removeEmployee(int empId);
	Employee findByEmployeeId(int empId);
	String forgotPassword(String empName);
	Employee updateEmployeeDetails(Employee list);
	
}

