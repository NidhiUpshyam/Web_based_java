package com.employee.dao;

import java.util.List;

import com.employee.dto.Leaves;

public interface LeaveDao {

	void insertLeave(Leaves leave);

	List<Leaves> findLeavebyEmpId(int empId);

	List<Leaves> selectAllLeaves();

	Leaves findByLeaveId(int leaveId);

	void updateLeave(Leaves l);
	
}
