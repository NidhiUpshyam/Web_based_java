package com.employee.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.employee.dto.Employee;
import com.employee.dto.Leaves;

@Repository
public class LeaveDaoImple implements LeaveDao{
	@Autowired
	private HibernateTemplate hibernateTemplate;


	@Override
	public void insertLeave(Leaves leave) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {
		       
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(leave);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});

		
	}


	@Override
	public List<Leaves> findLeavebyEmpId(int empId) {
		// TODO Auto-generated method stub
		return hibernateTemplate.execute(new HibernateCallback<List<Leaves>>() {

			@Override
			public List<Leaves> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Leaves where empId=?");
				q.setInteger(0, empId);
				List<Leaves> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
	}


	@Override
	public List<Leaves> selectAllLeaves() {
		// TODO Auto-generated method stub
		return hibernateTemplate.execute(new HibernateCallback<List<Leaves>>() {

			@Override
			public List<Leaves> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from Leaves");
				List<Leaves> li = q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
	}


	@Override
	public Leaves findByLeaveId(int leaveId) {
		// TODO Auto-generated method stub
		return hibernateTemplate.execute(new HibernateCallback<Leaves>() {

			@Override
			public Leaves doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Leaves e=(Leaves) session.get(Leaves.class,leaveId);
				tr.commit();
				session.flush();
				session.close();
				return e;
			}
			
		});
	}


	@Override
	public void updateLeave(Leaves l) {
		// TODO Auto-generated method stub
		hibernateTemplate.execute(new HibernateCallback<Void>() {
			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
				Leaves leave = (Leaves)session.get(Leaves.class,l.getLeaveId());
				leave.setLeaveStatus(l.getLeaveStatus());
				
				session.update(leave);			
				tr.commit();
				session.flush();
				session.close();
				return null;
			}			
		});

	}
	
	

}
