package com.employee.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.employee.dto.Employee;
@Service
public class RegValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Employee.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empName","unmKey", "user name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empPass", "passKey","password required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empCity", "cityKey","city required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empJob", "jobKey","job required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empMobNo", "mobKey","mobNo required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empDOB", "dobKey","DOB required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empDOJ", "dojKey","DOJ required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empMail", "mailKey","Mail required");
	
		
		Employee employee = (Employee)target;
		if(employee.getEmpPass()!=null) {
			if(employee.getEmpPass().length()<3) { 
				errors.rejectValue("empPass", "passKey", "password should contain more 2 chars");
			}
		}
		
	      if(employee.getEmpMail()!=null) {
	    	  String regex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                      "[a-zA-Z0-9_+&*-]+)*@" + 
                      "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                      "A-Z]{2,7}$";
		      //Matching the given email with regular expression
		      boolean result = employee.getEmpMail().matches(regex);
		      if(!result) {
		    	  errors.rejectValue("empMail", "mailKey", "enter valid email"); 
		      }
				
			}
	      
	      if(employee.getEmpMobNo()!=null) {
	    	  String regex = "^(0/91)?[7-9][0-9]{9}$";
		      //Matching the given mobile no.  with regular expression
		      boolean result = employee.getEmpMobNo().matches(regex);
		      if(!result) {
		    	  errors.rejectValue("empMobNo", "mobKey", "enter valid mobile no."); 
		      }
				
			}
		
		
	}

}
