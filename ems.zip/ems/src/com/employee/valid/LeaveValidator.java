package com.employee.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.employee.dto.Leaves;

@Service
public class LeaveValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return clazz.equals(Leaves.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		// TODO Auto-generated method stub
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empId","empKey", "user id required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "fromDate", "fromKey","from date required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "toDate", "toKey","to date required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "leaveType", "typeKey","leave type required");
		
		
	
	}

}
