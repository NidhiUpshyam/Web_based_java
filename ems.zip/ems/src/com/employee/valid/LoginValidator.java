package com.employee.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.employee.dto.Employee;

@Service
public class LoginValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(Employee.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empName","unmKey", "user name required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "empPass", "passKey","password required");
	
		
		Employee employee = (Employee)target;
		Employee emp;
		if(employee.getEmpPass()!=null) {
			if(employee.getEmpPass().length()<3) { 
				errors.rejectValue("empPass", "passKey", "password should contain more 2 chars");
			}
		}
		
		
	}
	
}

